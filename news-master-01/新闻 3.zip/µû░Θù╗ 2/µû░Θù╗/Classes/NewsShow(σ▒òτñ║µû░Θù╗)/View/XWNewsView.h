//
//  XWNewsView.h
//  新闻
//
//  Created by user on 15/10/2.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XWNewsFrameModel;

@interface XWNewsView : UIView

@property (nonatomic,strong) XWNewsFrameModel *frameModel;

@end

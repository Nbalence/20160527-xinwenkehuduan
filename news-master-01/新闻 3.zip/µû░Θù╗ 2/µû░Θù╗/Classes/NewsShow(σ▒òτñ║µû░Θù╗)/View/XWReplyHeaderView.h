//
//  XWReplyHeaderView.h
//  新闻
//
//  Created by user on 15/10/4.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XWReplyHeaderView : UIView


+(instancetype)shareWithTitle:(NSString*)title;

@end

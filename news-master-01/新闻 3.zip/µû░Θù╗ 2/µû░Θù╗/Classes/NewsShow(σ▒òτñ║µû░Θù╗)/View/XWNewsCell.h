//
//  XWNewsCell.h
//  新闻
//
//  Created by user on 15/10/2.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XWNewsFrameModel;

@interface XWNewsCell : UITableViewCell

@property (nonatomic,strong) XWNewsFrameModel *frameModel;

+(instancetype)cellWithTableView:(UITableView*)tableView indextifier:(NSString*)indextifier;

@end

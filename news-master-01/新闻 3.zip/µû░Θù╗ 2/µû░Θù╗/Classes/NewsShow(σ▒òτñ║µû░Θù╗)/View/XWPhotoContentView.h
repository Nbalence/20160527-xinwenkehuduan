//
//  XWPhotoContentView.h
//  新闻
//
//  Created by user on 15/10/4.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

#define photoContentH  80

@interface XWPhotoContentView : UIView

@property (nonatomic,weak) UILabel *titleLabel;
@property (nonatomic,weak) UILabel *numLabel;
@property (nonatomic,weak) UITextView *contentText;

@end

//
//  XWPhotoBottomView.h
//  新闻
//
//  Created by user on 15/10/4.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

#define photoBottomH  50

typedef enum
{
    buttonDownloadType,
    buttonShareType,
    buttonLikeType
}buttonType;

@interface XWPhotoBottomView : UIView

@end

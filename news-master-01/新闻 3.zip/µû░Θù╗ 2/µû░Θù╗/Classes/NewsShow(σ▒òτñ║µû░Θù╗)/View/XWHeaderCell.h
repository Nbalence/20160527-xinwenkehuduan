//
//  HGScrollCell.h
//  HiGo
//
//  Created by Think_lion on 15/7/26.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XWNewsModel;


@interface XWHeaderCell : UICollectionViewCell


@property (nonatomic,strong) XWNewsModel *newsModel;


@end

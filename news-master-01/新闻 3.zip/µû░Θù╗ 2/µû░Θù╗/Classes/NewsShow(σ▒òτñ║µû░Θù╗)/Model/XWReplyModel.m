//
//  XWReplyModel.m
//  新闻
//
//  Created by user on 15/10/3.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "XWReplyModel.h"

@implementation XWReplyModel

@end

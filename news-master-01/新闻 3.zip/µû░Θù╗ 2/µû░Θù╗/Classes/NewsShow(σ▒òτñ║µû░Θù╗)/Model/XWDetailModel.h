//
//  XWDetailModel.h
//  新闻
//
//  Created by user on 15/10/3.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XWDetailModel : NSObject


@property (nonatomic,copy) NSString *body;
//@property (nonatomic,copy) NSString *replyCount;
//@property (nonatomic,copy) NSString *docid;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *source;
@property (nonatomic,copy) NSString *ptime;


@property (nonatomic,copy) NSString *spinfo; //扩展阅读部分
@property (nonatomic,strong) NSMutableArray *img; //存放的图片那模型数据  XWDetailImgModel

+(instancetype)initWithDict:(NSDictionary*)dict;

@end

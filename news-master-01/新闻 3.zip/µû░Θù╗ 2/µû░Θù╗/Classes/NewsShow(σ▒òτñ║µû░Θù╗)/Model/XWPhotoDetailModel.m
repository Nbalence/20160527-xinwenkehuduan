//
//  XWPhotoDetailModel.m
//  新闻
//
//  Created by user on 15/10/4.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "XWPhotoDetailModel.h"

@implementation XWPhotoDetailModel

@end

//
//  XWDetailContentController.h
//  新闻
//
//  Created by user on 15/10/3.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XWNewsModel;

@interface XWDetailContentController : UIViewController

@property (nonatomic,strong) XWNewsModel *newsModel;



@end

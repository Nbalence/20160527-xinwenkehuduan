//
//  XWPhotoController.h
//  新闻
//
//  Created by user on 15/10/4.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>
@class  XWNewsModel;

@interface XWPhotoController : UIViewController

@property (nonatomic,strong) XWNewsModel *newsModel; //新闻模型

@end

//
//  XWReplyController.h
//  新闻
//
//  Created by user on 15/10/3.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XWReplyController : UIViewController

@property(nonatomic,strong) NSMutableArray *replys;

@property (nonatomic,copy) NSString *statusBar; //有内容的话 

@end

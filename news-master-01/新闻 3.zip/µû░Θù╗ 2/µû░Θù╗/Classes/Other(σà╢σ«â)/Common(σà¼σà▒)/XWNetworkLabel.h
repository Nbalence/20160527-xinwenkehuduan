//
//  MyLabel.h
//  新闻
//
//  Created by Think_lion on 15/5/11.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XWNetworkLabel : UILabel

@property (nonatomic,copy) NSString *textStr;

@end

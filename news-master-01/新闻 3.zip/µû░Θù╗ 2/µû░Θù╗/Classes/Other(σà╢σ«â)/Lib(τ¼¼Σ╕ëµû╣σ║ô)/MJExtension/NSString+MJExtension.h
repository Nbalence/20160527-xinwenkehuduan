//
//  NSString+MJExtension.h
//  TestTabBar
//
//  Created by MJ Lee on 15/4/17.
//  Copyright (c) 2015年 Mac Z. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MJExtension)
- (id)JSONObject;
@end

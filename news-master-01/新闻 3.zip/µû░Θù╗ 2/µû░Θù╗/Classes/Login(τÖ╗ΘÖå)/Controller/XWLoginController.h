//
//  XWLoginController.h
//  新闻
//
//  Created by user on 15/9/5.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XWLoginController : UIViewController
@property (nonatomic,copy) NSString *dismissType; //判断怎么销毁该控制器  如果有值 就pop
@end

//
//  XWBaseSettingController.h
//  新闻
//
//  Created by lairen on 15/9/7.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XWBaseSettingController : UITableViewController

@property (nonatomic,strong) NSMutableArray *datas; //存放的所有分组数据


@end

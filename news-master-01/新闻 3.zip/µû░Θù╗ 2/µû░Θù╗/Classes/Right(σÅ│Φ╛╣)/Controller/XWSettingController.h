//
//  XWSettingController.h
//  新闻
//
//  Created by lairen on 15/9/7.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "XWBaseSettingController.h"

@interface XWSettingController : XWBaseSettingController

@end

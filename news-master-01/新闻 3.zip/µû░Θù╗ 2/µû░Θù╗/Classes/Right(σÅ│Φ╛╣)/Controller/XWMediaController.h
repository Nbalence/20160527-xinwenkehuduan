//
//  XWMediaController.h
//  新闻
//
//  Created by lairen on 15/9/6.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XWMediaController : UIViewController

@end

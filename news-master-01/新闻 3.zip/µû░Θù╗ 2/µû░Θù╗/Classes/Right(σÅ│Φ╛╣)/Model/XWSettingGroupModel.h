//
//  XWSettingGroupModel.h
//  新闻
//
//  Created by lairen on 15/9/7.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XWSettingGroupModel : NSObject

@property (nonatomic,copy) NSString *header;
@property  (nonatomic,copy) NSString *footer;
@property (nonatomic,strong) NSArray *items; //数组里面存放的时XWCellitem模型

@end

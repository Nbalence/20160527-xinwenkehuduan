//
//  XWLabelItem.h
//  新闻
//
//  Created by lairen on 15/9/7.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "XWCellItem.h"

@interface XWLabelItem : XWCellItem

@property (nonatomic,copy) NSString *cacheSize;

+(instancetype)itemWithIcon:(NSString*)icon title:(NSString *)title cacheSize:(NSString*)cacheSize;

@end

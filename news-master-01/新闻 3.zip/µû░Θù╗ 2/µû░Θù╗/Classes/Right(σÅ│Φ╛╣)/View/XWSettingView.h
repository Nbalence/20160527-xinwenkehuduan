//
//  XWSettingView.h
//  新闻
//
//  Created by lairen on 15/9/7.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XWCellItem.h"
#import "XWArrowItem.h"
#import "XWSwitchItem.h"
#import "XWLabelItem.h"
#import "XWBosItem.h"

@class XWCellItem;

@interface XWSettingView : UIView

//定义模型
@property (nonatomic,strong) XWCellItem *item;

@end

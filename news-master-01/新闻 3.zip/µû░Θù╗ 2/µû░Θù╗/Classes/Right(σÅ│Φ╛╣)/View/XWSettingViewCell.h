//
//  XWSettingViewCell.h
//  新闻
//
//  Created by lairen on 15/9/7.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XWCellItem;
@interface XWSettingViewCell : UITableViewCell


+(instancetype)cellWithTableView:(UITableView*)tableView indextifier:(NSString*)indextifier;

@property (nonatomic,strong) XWCellItem *item; //模型

@end
